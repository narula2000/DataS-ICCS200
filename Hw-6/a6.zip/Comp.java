public class Comp {
	boolean found = true;

	void Notify() {
		found = false;
	}
}
